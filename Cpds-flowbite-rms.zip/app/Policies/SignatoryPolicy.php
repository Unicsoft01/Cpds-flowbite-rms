<?php

namespace App\Policies;

use App\Models\Signatory;
use App\Models\User;
use Illuminate\Auth\Access\Response;

class SignatoryPolicy
{
    /**
     * Determine whether the user can view any models.
     */
    public function viewAny(User $user): bool
    {
        return false;
    }

    /**
     * Determine whether the user can view the model.
     */
    public function view(User $user, Signatory $signatory): bool
    {
        return  $user->hasRole('User') || $user->hasRole('Super_admin');
    }

    /**
     * Determine whether the user can create models.
     */
    public function create(User $user): bool
    {
        return  $user->hasRole('User') || $user->hasRole('Super_admin');
    }

    /**
     * Determine whether the user can delete the model.
     */
    public function delete(User $user, Signatory $signatory): bool
    {
        return  $user->hasRole('User') || $user->hasRole('Super_admin');
    }

    /**
     * Determine whether the user can restore the model.
     */
    public function restore(User $user, Signatory $signatory): bool
    {
        return false;
    }

    /**
     * Determine whether the user can permanently delete the model.
     */
    public function forceDelete(User $user, Signatory $signatory): bool
    {
        return false;
    }
}
