<?php

namespace App\Enums;

enum SemestersEnum
{
    //
}
