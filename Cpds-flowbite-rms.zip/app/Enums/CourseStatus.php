<?php

namespace App\Enums;

enum CourseStatus: string
{
    case  Core = 'C';
    case  Elective = 'E';
}