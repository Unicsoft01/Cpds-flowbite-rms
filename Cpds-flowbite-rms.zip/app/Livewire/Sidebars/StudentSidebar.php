<?php

namespace App\Livewire\Sidebars;

use Livewire\Component;

class StudentSidebar extends Component
{
    public function render()
    {
        return view('sidebars.student-sidebar');
    }
}
