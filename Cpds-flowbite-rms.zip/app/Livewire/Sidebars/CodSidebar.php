<?php

namespace App\Livewire\Sidebars;

use Livewire\Component;

class CodSidebar extends Component
{
    public function render()
    {
        return view('sidebars.cod-sidebar');
    }
}
