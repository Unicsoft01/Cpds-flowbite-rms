<?php

namespace App\Livewire\Sidebars;

use Livewire\Component;

class DirectorSidebar extends Component
{
    public function render()
    {
        return view('sidebars.director-sidebar');
    }
}
