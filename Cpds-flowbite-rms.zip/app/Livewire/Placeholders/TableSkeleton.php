<?php

namespace App\Livewire\Placeholders;

use Livewire\Component;

class TableSkeleton extends Component
{
    public function render()
    {
        return view('placeholders.table-skeleton');
    }
}
