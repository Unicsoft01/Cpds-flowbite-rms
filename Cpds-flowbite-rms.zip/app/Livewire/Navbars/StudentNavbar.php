<?php

namespace App\Livewire\Navbars;

use Livewire\Component;

class StudentNavbar extends Component
{
    public function render()
    {
        return view('navbars.student-navbar');
    }
}
