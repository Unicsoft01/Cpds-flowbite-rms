<th scope="col"
    {{ $attributes->merge(['class' => 'p-4 text-xs font-medium text-left text-gray-500 uppercase dark:text-gray-400 text-center']) }}>
    {{ $slot }}
</th>
