<div>
    <div class="print:hiddens pt-6">
        <div class="grid grid-cols-1">
            <!-- Main widget -->
            <div
                class="bg-white dark:bg-indigo-300">
                {{-- school details --}}
                <div style="width:1500px;margin-left:20%;">
                    <div title="logo" style="width:120px;float:left;">
                        <img src="{{ url('/') }}/images/logo.jpg" width="90px" height="110px">
                    </div>

                    <div title="logo"
                        style="width:600px;float:left;text-transform:uppercase;font-weight:bold;line-height:15px;">
                        <h2>KOGI STATE UNIVERSITY, ANYIGBA</h2>
                        <p style="font-size:14px;">Faculty of Social Sciences <br>
                            Department of Mass Communication<br>Examination Results</p>
                    </div>

                    <div title="logo" style="width:400px;float:left;">
                        <img src="{{ url('/') }}/images/logo.jpg" width="90px" height="110px">
                    </div>

                </div>
            </div>
        </div>
    </div>

</div>
